# Magoya · Brand System v1.2

> Manual de marca en Markdown, pensado para ser consumido por personas y por modelos de AI.
> Tokens exactos en [`tokens.json`](tokens.json) y [`tokens.css`](tokens.css). Manual visual navegable en [`brand-book.html`](brand-book.html).
> **Las reglas visuales de este archivo espejan las del brand book visual.** Si una regla cambia acá, cambia allá, y al revés.

**Regla madre del sistema:** todo asset que se puede usar tiene que estar en el brand, con su ficha: qué es, cuándo se usa, cuándo no, y de dónde se baja ([`library.html`](library.html)).

## 1. Qué es Magoya

> **Capa verbal: Magoya Brand Playbook y Guía editorial V2 (octubre de 2026).** La identidad, el posicionamiento, los territorios, la oferta, los espacios y el Método Magoya salen del playbook; la voz, el estilo, el vocabulario y la adaptación editorial salen de la Guía editorial ("Manual voz y tono MAGOYA V2"), en [`.ai/verbal/guia-editorial.md`](.ai/verbal/guia-editorial.md), cuya Parte II son las instrucciones operativas para agentes de AI. Esta sección resume lo esencial; el detalle vive en `estrategia.html`, `voz.html`, `lenguaje.html` y `aplicacion.html`, y en su versión machine-readable: [`.ai/verbal/estrategia.md`](.ai/verbal/estrategia.md), [`.ai/verbal/voz.md`](.ai/verbal/voz.md), [`.ai/verbal/lenguaje.md`](.ai/verbal/lenguaje.md), [`.ai/verbal/aplicacion.md`](.ai/verbal/aplicacion.md) y [`vocabulary.json`](vocabulary.json). Antes de entregar un texto: [`.ai/checklist-verbal.md`](.ai/checklist-verbal.md). Si algo de acá difiere de la fuente que corresponde, prevalece la fuente. La capa visual (§2 a §9) se actualizó con el feedback del equipo del 22 de octubre de 2026.

**Definición.** Magoya es una consultora hands-on en software y AI para empresas del agro. *Magoya is a hands-on software and AI consulting firm for agribusiness.* "Estrategia y ejecución" no se usa para definir a Magoya: lo reemplaza **hands-on**; y "tecnología" no reemplaza a "software y AI" en la definición o el tagline (en otros contextos puede usarse).

**Tagline.** **Software and AI for agribusiness.**

**Territorios de posicionamiento, por peso en los mensajes:** **Uso 50%** ("El éxito no es llegar al lanzamiento del producto. El éxito es que ese producto se use.") · **Integración 30%** ("Nuestra primera opción es construir sobre lo que ya existe.") · **Hands-on 20%** ("Ejecutamos lo que proponemos."). El 50/30/20, y el 70/30 de cada vocero, son guías de planificación de contenidos, no un chequeo de cada texto.

**Personalidad:** cuatro rasgos, en este orden, y cada uno ecualiza al siguiente: **Estratega · Responsable · Curiosa · Franca**. En inglés, Responsable se traduce *Accountable*, no *responsible*.

**AI.** Se escribe **AI**, en inglés, para nombrar la inteligencia artificial en cualquier idioma del texto. Única excepción: **IA en Campo**, nombre propio del programa, que se escribe siempre así (nunca "AI en Campo").

**Voz.** Convicción sin soberbia, constructiva, como partner, clara y honesta, centrada en el uso y el valor. Los diales por país son orientativos: la identidad no cambia por mercado.

**Vocabulario.** Se evitan las etiquetas reductoras para definir a Magoya (software factory, dev shop, agtech como categoría identitaria, custom como promesa central, transformación digital como definición); no son palabras universalmente vetadas, se evalúan por función y contexto. La lista del playbook (agtech · digital (solo) · transformación digital · custom · software factory · dev shop · agencia · tecnología (sola) · ayudar · adopción como sinónimo de uso · DIPI · building blocks), con sus reemplazos y el glosario ES · EN · PT, está en [`vocabulary.json`](vocabulary.json). Decimos "uso" antes que "adopción".

**Reglas operativas para AI (guía, Parte II).** No se inventan hechos, cifras, resultados, citas ni clientes. Toda métrica real la valida alguien del equipo (fuente, responsable, fecha, definición y alcance) y vive en [`ai/facts.json`](ai/facts.json). Los clientes no se nombran por defecto. Se distingue hecho validado, interpretación, hipótesis y ejemplo ilustrativo. Si hay decisiones, riesgos o cifras en juego, se entrega un borrador pendiente de revisión. Un conflicto entre fuentes se señala, no se resuelve en silencio.

**Idioma.** El inglés es el idioma principal del website, de LinkedIn y de Instagram. La personalidad es la misma en Argentina, Brasil y Estados Unidos; lo que cambia por mercado es el vocabulario, el estadio de construcción y el énfasis por audiencia.

## 2. Logo & avatares

- **Wordmark** redondeado (4 versiones: verde digital `#00DE68` sobre blanco · crema sobre verde profundo · negro `#161616` sobre blanco · verde profundo sobre crema). Nunca reconstruir ni alterar espaciado. Versión web animada: `assets/magoya-wordmark-animado.svg`.
- **Avatares** (círculo `#00DE68` + marca blanca): `go`, `o`, `cara`, `m`. La **cara** = redes de comunidad; la **m** = monograma funcional (favicon, app icon, canales corporativos).
- Aire mínimo: la altura de la "m". Tamaño mínimo: 90px pantalla / 24mm impreso. Más chico que eso, usar el avatar "m".
- ✗ No estirar, rotar, sombrear, degradar. ✗ Wordmark en lima. ✗ Recolorear avatares.

## 3. Color

| Color | HEX | Pantone (aprox.) | Rol |
|---|---|---|---|
| Verde Magoya | `#133825` | PMS 553 | **El verde protagonista de Magoya**: fondos, overlays, superficies oscuras, texto sobre claro |
| Verde digital | `#00DE68` | PMS 3282 | Identidad: wordmark, avatares, micro-acentos y data-viz. Como texto SOLO sobre oscuro |
| Lima | `#A2FF00` | PMS 382 2X | **Solo acentos, detalles, resaltar o CTA.** Nunca texto sobre blanco |
| Crema Magoya | `#ECE3DB` | PMS Warm Gray 2 | Neutro cálido; texto sobre verde profundo |
| Sage | `#EEF2EC` | PMS Cool Gray 1 | Superficie clara |
| Negro Magoya | `#161616` | PMS Black 5 2X | Texto, titulares, cards dark |

Los Pantone son el **match más cercano por distancia RGB** contra la librería Solid Coated (no existe una conversión exacta hex→Pantone): confirmar contra el libro físico antes de mandar a producción.

**Regla de color.** Ahora que el lima es uno de los colores de la paleta de IA en Campo, Magoya potencia el **Verde Magoya `#133825`** como su verde protagonista y deja el **lima** para acentos, detalles, resaltar o CTA.

**Proporciones de uso: pendientes de definir.** La proporción por porcentajes que regía antes quedó sin efecto y todavía no hay una nueva. No apliques porcentajes ni inventes una proporción.

**Accesibilidad (no negociable):** lima nunca como texto sobre claro (1.25:1). Verde sobre blanco como texto = `#009145` y solo ≥24px bold. `#00DE68` como texto solo sobre fondos oscuros. Captions sobre claro: mínimo `#6E756D`.

## 4. Tipografía

**Manrope** (variable 200–800, self-hosted). Fallback: **Arial**. Display ExtraBold 800 con tracking −3%; cuerpo Regular 400. Kickers MAYÚSCULAS +12% tracking.

Reglas: **3 niveles tipográficos** por pieza; el peso hace la jerarquía; labels de botón en sentence case. **Emojis: nunca en títulos**; solo se permiten manitos que señalan (👈 👉 👇) para dirigir a un CTA y banderas de países para geografía, ningún otro.

**Resaltar una palabra:** con un **círculo** que la rodea o con **flechas** que la señalan. Nunca subrayado y nunca un bloque resaltador sólido detrás del texto. Las marcas a mano (`assets/flourish-circle.svg`, `assets/flourish-arrow.svg`) van en **verde digital `#00DE68` sobre claro / lima sobre oscuro** (nunca en negro: contra el texto no resaltan), una sola por pieza y siempre sobre texto compuesto, nunca sueltas como adorno. El círculo marca una palabra, una fecha o un dato puntual; la flecha también puede señalar el CTA: nace del texto y su punta cae sobre el botón.

## 5. Fotografía

Dos familias fotográficas, cada una con su regla:
- **Aérea de campo**: color natural, con **overlay verde profundo** (scrim 55–86%) para fondos con texto. **Siempre enfoque cenital.** El scrim es el único gradiente permitido.
- **Personas**: gente real del equipo, **siempre a color** y mejor **en espacios abiertos**. Sin ningún detalle encima: ni barra, ni acento verde, ni overlay. Luz natural, gesto genuino.
- ✗ Stock corporativo posado, oficinas genéricas. ✗ Fotos de personas en blanco y negro o con un detalle de color encima. ✗ Fotos de campo que no sean cenitales.

## 6. Iconografía

Línea 2px, terminaciones y esquinas redondeadas, grid 24×24, `currentColor`. **Set agro de 16 íconos + 10 logos de AI + 13 de redes en `assets/studio/icons/`, los mismos archivos que usa Magoya Studio.** Negro sobre claro, crema sobre oscuro, **lima solo el ícono destacado (uno por pieza)**. Librería propia de 58 iconos en 7 categorías (`icons.html`); completar con Lucide (misma gramática) si hace falta volumen. Nunca rellenos sólidos ni 3D.

## 7. Componentes

- **Botón ≠ chip.** Botón: rectángulo radio 10px, fondo sólido (lima = CTA primario, negro, verde profundo, ghost). Chip: **pill outline**, borde y texto del mismo color, fondo transparente. Nunca chip sólido ni botón pill. **El chip lleva SOLO texto** (uppercase, tracking .1em): nunca un punto/bullet delante, nunca un ícono adentro. La pill ya delimita, el punto es ruido (acuerdo explícito del equipo).
- **Espaciado sistematizado.** Todo margin/padding/gap sale de la escala base-4 de `tokens.json` (4/8/12/16/24/32/48/64/96), nunca valores arbitrarios. Aire entre bloques ≥24; dentro de un componente 8–16. Paddings canónicos: botón 13px/26px, chip 6px/15px (spec completa en `components` de `tokens.json`).
- **Alineación.** Una pieza tiene UN eje principal (por defecto, izquierda): todos los bloques de texto arrancan ahí. Los elementos de una fila comparten centro vertical y un gap único (8 o 12). Padding interno simétrico, nunca 4 valores distintos.
- Estados: hover (lima→`#8BDB00`, resto brightness), focus ring `rgba(0,222,104,.45)` sin blur.
- **Cards: siempre en mosaico**: misma grilla, mismos aires, alturas que calzan; nunca sueltas. Tipos: hiring (negro + lima), quote (foto + cita), stat (número 800 −3%). El contacto dentro de una card dark es un **link en lima**, no un botón (los botones viven fuera de las cards).
- ✗ **El monograma "m" circular NO va en cards.** El avatar "m" es identidad de canal (favicon, app icon, perfil corporativo) y pie de papelería; dentro de una card compite con el wordmark y agrega un segundo logo a la pieza. En una card, la marca es el wordmark.
- Logo wall: logos **siempre reales**, en gris, grilla pareja.

## 8. Papelería & corporativo

- **Membrete A4**: wordmark verde arriba-izq (20% del ancho), pie con filete verde digital + avatar m. Header y footer vectoriales listos: `assets/downloads/doc-header.svg` · `doc-footer.svg`.
- Docs: wordmark esquina sup-izq ≤1/5 del ancho; Manrope o Arial; nunca logo como marca de agua.

## 9. Reglas de oro (resumen ejecutable)

1. El Verde Magoya `#133825` es el verde protagonista. Las proporciones de uso están pendientes de definir: no apliques porcentajes.
2. Lima solo para acentos, detalles, resaltar o CTA.
3. Verde digital `#00DE68` = identidad (logo/avatares); lima ≠ logo.
4. Personas siempre a color, sin ningún detalle encima, mejor en espacios abiertos. Aérea de campo siempre cenital. Magoya no usa ilustración.
5. Logos de clientes SIEMPRE reales, jamás placeholders.
6. Todo redondeado, como el wordmark. Botón rect 10px, chip pill outline.
7. Para resaltar una palabra: círculo o flechas. Nunca subrayado.
8. El monograma "m" no va en cards.
9. **Emojis prohibidos**: la única excepción son las manitos que señalan (👈 👉 👇) hacia un CTA y las banderas de países para geografía. Nunca en títulos.
10. ✗ Pieza 100% negra o 100% verde (siempre equilibrio) · ✗ Resaltador sólido tras texto · ✗ gradientes glossy/3D/estética AI · ✗ puzzle (metáfora del brand viejo) · ✗ naranja/amarillo del brand viejo.
11. **AI, en cualquier idioma**: se escribe AI para nombrar la inteligencia artificial, también en textos en español. Única excepción: el nombre propio **IA en Campo**. Regla del Brand Playbook (slide 50); el resto de la capa verbal en §1.

## 10. IA en Campo (manual propio)

**No es una sección de este brand: es una marca de programa presentada por Magoya, con su propio manual** (`ai-en-campo.html`). Programa abierto de AI aplicada al agro (carruseles, reels, webinars). Mismo ADN (Manrope, verdes oficiales) pero **rompe tres reglas del core a propósito**: (1) lienzo **verde digital pleno #00DE68** como fondo dominante; (2) **placa negra** #161616 con texto crema para el dato clave — permitida acá como lenguaje sticker; (3) **ruido con los assets del Studio** (`assets/studio/`): doodles (sparkle, dots, blob, loop), flourishes (arrow, navarrow, circle, underline), badge EN VIVO y logos oficiales de AI/redes — 2–4 por pieza, ±5–15°, en las esquinas, teñidos en verde digital o lima (nunca un color propio: la sub-marca no usa terracota ni ningún acento fuera de la paleta core). Texto secundario verde profundo; display negro. Formato madre: **carrusel retrato 4:5 (1080×1350)** — no el cuadrado 1080×1080, que Instagram dejó de privilegiar para carruseles. Arco narrativo de 4–6 slides (duda real → herramienta → prueba → paso siguiente), sin numerar las slides (el swipe ya lo comunica); **ritmo de color del arco: verde pleno en la primera y la última slide, crema Magoya en las del medio** — todo verde se lee como una sola pieza repetida, no como un recorrido.

**Logo del programa:** lockup **"IA en Campo · por Magoya"** (hasta que exista el lockup con "presentado por Magoya") abajo-izquierda — reemplaza al wordmark de Magoya solo en piezas de esta línea. Se compone con Manrope viva (800, tracking −2%), nunca como imagen. Lleva un mark a mano (`assets/studio/mark-ai-campo.svg`, mismo lenguaje de las marcas a mano del core) pegado a la derecha de "IA", a ~65% de su altura — **ese mark existe únicamente en este tamaño**: agrandado y suelto en una esquina como estallido cómic queda fuera del sistema. Negro `#161616` sobre lienzo claro, crema `#ECE3DB` sobre placa negra; nunca lima ni verde digital en el lockup — el color lo pone el fondo, no el logo. "por Magoya" siempre en `font-mono`, mayúsculas, más chico: es la firma, no el título.

Las piezas se producen SIEMPRE desde plantillas del Studio y su receta queda guardada en un `.magoya.json` (template, scheme, accent, anchor, rule, silueta, objetos con x/y/scale/rotation) — esa es la fuente para reproducirlas, no el ojo. Producción en Magoya Studio (30+ plantillas, 13 formatos de red). Nada de esto vuelve al core.

## Mapa de archivos del sistema

| Página | Qué documenta |
|---|---|
| `estrategia.html` · `voz.html` · `lenguaje.html` · `aplicacion.html` | Capa verbal del Brand Playbook (octubre 2026) |
| `brand-book.html` | Identidad visual: logo, color, tipografía, fotografía, iconografía, componentes, reglas de oro |
| `library.html` | Recursos: ficha + descarga de cada asset aprobado |
| `icons.html` | 58 iconos copiables |
| `logos.html` | Logos de clientes y stack tecnológico |
| `ai-en-campo.html` | Manual completo de IA en Campo |
| `ai.html` | Integrar con AI: cómo cargar esta marca en una herramienta de AI y cómo validar el resultado |

Capa machine-readable: `llms.txt` (resumen estable), `.ai/brand-prompt.md` y `.ai/brand-prompt-short.md` (prompts para pegar), `.ai/checklist.md` (validación visual), `.ai/checklist-verbal.md` (validación de texto), `.ai/verbal/` y `vocabulary.json` (capa verbal) y `.ai/presets/` (uno por herramienta). **Todos derivan de este archivo: si una regla cambia acá, hay que propagarla ahí.**

`assets/refs/` es **material fuente no publicable** (exports originales del diseñador): se conserva como referencia de trazado, no se enlaza ni se distribuye.

---

*Pendientes de contenido: proporciones de uso del color; fotos a color del equipo (hoy solo hay una, de Varu); logos vectoriales de ProducePay/HabiTerre/IntelinAir; validación de Staff Augmentation; unificación del email de contacto (hoy conviven `people@` e `info@`).*
